
const root = document.getElementById('root');
root.innerHTML = `
  <h1>Welcome to MyNova Hostels</h1>
  <p>Explore mountains, waterfalls, and more – right outside your door.</p>
`;
